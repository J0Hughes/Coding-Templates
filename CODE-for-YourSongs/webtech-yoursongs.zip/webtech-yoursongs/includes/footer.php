 <!-- Include inserts a footer on all pages. Shares reusesable content-->

        <footer>
	        <div class="container">  

                <p>All rights reserved | Website created by Joanne Hughes &commat; JJ Digital Media</p>
                <p><a href="http://validator.w3.org/check?uri=referer" title="W3C HTML Validation Service">Valid HTML</a> | Student Coursework &copy; <a href="http://www.mmu.ac.uk/" title="MMU homepage">MMU 2018</a> | Tutor <a href="mailto:c.dawson@mmu.ac.uk">Chris Dawson</a></p>
			
	        </div><!-- eof container -->
        </footer><!-- eof footer -->
        

    </body>
</html>



    
       
 
